#!/usr/bin/env bash
set -euo pipefail

# OpenAMRobot UI - one-command bootstrap
# - In Codespaces / devcontainer: installs project deps and builds everything.
# - On local Ubuntu: can also install ROS 2 Jazzy with --with-ros.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
  cat <<'USAGE'
Usage:
  ./bootstrap.sh                # assumes ROS 2 is already available (recommended in Codespaces/devcontainer)
  ./bootstrap.sh --with-ros     # installs ROS 2 Jazzy on Ubuntu 24.04 if missing, then bootstraps the project
  ./bootstrap.sh --help

Notes:
- This script does NOT modify your shell rc files (e.g., ~/.bashrc).
- If ROS is installed, you still need to source it in your current shell:
    source /opt/ros/jazzy/setup.bash
USAGE
}

WITH_ROS=0
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  usage
  exit 0
fi
if [[ "${1:-}" == "--with-ros" ]]; then
  WITH_ROS=1
fi

have_ros() {
  command -v ros2 >/dev/null 2>&1 || [[ -f "/opt/ros/jazzy/setup.bash" ]]
}

if have_ros; then
  exec "${ROOT_DIR}/scripts/bootstrap_project.sh"
fi

if [[ ${WITH_ROS} -eq 1 ]]; then
  exec "${ROOT_DIR}/scripts/bootstrap_ubuntu.sh"
fi

cat <<'MSG'
ROS 2 Jazzy was not detected in this environment.

Recommended options:
1) Use Codespaces / devcontainer (fastest, most reproducible).
2) On Ubuntu 24.04, install ROS 2 Jazzy and bootstrap everything:
     ./bootstrap.sh --with-ros
MSG
exit 1
