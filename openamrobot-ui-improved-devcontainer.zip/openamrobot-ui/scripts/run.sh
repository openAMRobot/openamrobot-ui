#!/usr/bin/env bash
set -euo pipefail

# run.sh
# Unified entrypoint for local/Codespaces usage.
#
# Examples:
#   ./scripts/run.sh --build-all
#   ./scripts/run.sh --build-frontend
#   ./scripts/run.sh --build-ros
#   ./scripts/run.sh --launch
#
# Notes:
# - Assumes ROS2 is installed and 'ros2' is available in PATH.
# - If you need to source ROS, do it before running this script:
#     source /opt/ros/<distro>/setup.bash

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROS_WS="${REPO_ROOT}/ros2"

BUILD_FRONTEND=false
BUILD_ROS=false
LAUNCH=false

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 [--build-all|--build-frontend|--build-ros|--launch]"
  exit 1
fi

while [ "$#" -gt 0 ]; do
  case "$1" in
    --build-all)
      BUILD_FRONTEND=true
      BUILD_ROS=true
      shift
      ;;
    --build-frontend)
      BUILD_FRONTEND=true
      shift
      ;;
    --build-ros)
      BUILD_ROS=true
      shift
      ;;
    --launch)
      LAUNCH=true
      shift
      ;;
    *)
      echo "ERROR: Unknown argument: $1"
      echo "Usage: $0 [--build-all|--build-frontend|--build-ros|--launch]"
      exit 1
      ;;
  esac
done

if [ "${BUILD_FRONTEND}" = true ]; then
  "${REPO_ROOT}/scripts/build_frontend.sh"
fi

if [ "${BUILD_ROS}" = true ]; then
  "${REPO_ROOT}/scripts/build_ros.sh"
fi

if [ "${LAUNCH}" = true ]; then
  if [ ! -d "${ROS_WS}/install" ]; then
    echo "ERROR: ROS workspace is not built yet (ros2/install not found)."
    echo "Run: ./scripts/run.sh --build-ros"
    exit 1
  fi

  # Source workspace overlays
  # shellcheck disable=SC1091
  source "${ROS_WS}/install/setup.bash"

  echo "[run] Launching UI:"
  ros2 launch openamr_ui_package ui_launch.py
fi
