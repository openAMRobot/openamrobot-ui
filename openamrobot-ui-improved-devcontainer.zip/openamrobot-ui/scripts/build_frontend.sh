#!/usr/bin/env bash
set -euo pipefail

# build_frontend.sh
# Builds the frontend in ./web and installs/copies the build output into the ROS2 package:
#   ros2/openamr_ui_package/openamr_ui_package/static/
#   ros2/openamr_ui_package/openamr_ui_package/templates/index.html
#
# This script is designed to be:
# - idempotent (safe to run multiple times)
# - workspace-root independent (can be executed from anywhere)
# - Codespaces friendly

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WEB_DIR="${REPO_ROOT}/web"
ROS_PKG_DIR="${REPO_ROOT}/ros2/openamr_ui_package/openamr_ui_package"
ROS_STATIC_DIR="${ROS_PKG_DIR}/static"
ROS_TEMPLATES_DIR="${ROS_PKG_DIR}/templates"

if [ ! -d "${WEB_DIR}" ]; then
  echo "ERROR: web/ folder not found at: ${WEB_DIR}"
  exit 1
fi
if [ ! -f "${WEB_DIR}/package.json" ]; then
  echo "ERROR: web/package.json not found. Frontend sources are missing."
  exit 1
fi
if [ ! -d "${ROS_PKG_DIR}" ]; then
  echo "ERROR: ROS package folder not found at: ${ROS_PKG_DIR}"
  exit 1
fi

echo "[build_frontend] Repo root: ${REPO_ROOT}"
echo "[build_frontend] Building frontend in: ${WEB_DIR}"

cd "${WEB_DIR}"

# Install dependencies (prefer deterministic installs when lock file exists)
if [ -f package-lock.json ]; then
  echo "[build_frontend] npm ci"
  npm ci
else
  echo "[build_frontend] npm install"
  npm install
fi

echo "[build_frontend] npm run build"
npm run build

# Detect build output folder (Vite: dist/, CRA: build/)
if [ -d "${WEB_DIR}/dist" ]; then
  BUILD_OUT="${WEB_DIR}/dist"
elif [ -d "${WEB_DIR}/build" ]; then
  BUILD_OUT="${WEB_DIR}/build"
else
  echo "ERROR: No dist/ or build/ folder found after npm run build"
  exit 1
fi

echo "[build_frontend] Build output: ${BUILD_OUT}"
mkdir -p "${ROS_STATIC_DIR}" "${ROS_TEMPLATES_DIR}"

# Clean previous static assets (keep directory)
rm -rf "${ROS_STATIC_DIR:?}/"*

# Copy assets into ROS static
# - If build output has assets/ (typical Vite), copy it under static/assets/
# - Otherwise copy the whole build folder contents under static/
if [ -d "${BUILD_OUT}/assets" ]; then
  mkdir -p "${ROS_STATIC_DIR}/assets"
  cp -R "${BUILD_OUT}/assets/." "${ROS_STATIC_DIR}/assets/"
else
  cp -R "${BUILD_OUT}/." "${ROS_STATIC_DIR}/"
fi

# Install the built index.html as the Flask template.
# For Vite builds, index.html usually references /assets/... -> we rewrite to /static/assets/...
if [ -f "${BUILD_OUT}/index.html" ]; then
  INDEX_TMP="$(mktemp)"
  cp "${BUILD_OUT}/index.html" "${INDEX_TMP}"

  # Rewrite common asset paths for Flask static hosting
  #  - /assets/...  -> /static/assets/...
  #  - assets/...   -> /static/assets/...
  sed -i         -e 's|href="/assets/|href="/static/assets/|g'         -e 's|src="/assets/|src="/static/assets/|g'         -e 's|href="assets/|href="/static/assets/|g'         -e 's|src="assets/|src="/static/assets/|g'         "${INDEX_TMP}" || true

  cp "${INDEX_TMP}" "${ROS_TEMPLATES_DIR}/index.html"
  rm -f "${INDEX_TMP}"
  echo "[build_frontend] Updated Flask template: ${ROS_TEMPLATES_DIR}/index.html"
else
  echo "WARNING: No index.html found in build output. Flask template not updated."
fi

echo "[build_frontend] DONE: Frontend built and installed into ROS package."
