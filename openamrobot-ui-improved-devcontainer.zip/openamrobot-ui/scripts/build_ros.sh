#!/usr/bin/env bash
set -euo pipefail

# build_ros.sh
# Builds the ROS2 workspace located in ./ros2

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROS_WS="${REPO_ROOT}/ros2"

if [ ! -d "${ROS_WS}" ]; then
  echo "ERROR: ROS workspace folder not found at: ${ROS_WS}"
  exit 1
fi

echo "[build_ros] Building ROS workspace: ${ROS_WS}"
cd "${ROS_WS}"

# Optional: allow users to pass extra colcon args
COLCON_ARGS=("$@")

colcon build --symlink-install "${COLCON_ARGS[@]}"

echo "[build_ros] DONE: colcon build completed."
