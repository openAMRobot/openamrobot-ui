#!/usr/bin/env bash
set -euo pipefail

# Bootstraps dependencies and builds for the OpenAMRobot UI repo.
# Assumes ROS 2 Jazzy is available in this environment.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() { printf "\n==> %s\n" "$1"; }

die() { printf "\nERROR: %s\n" "$1" >&2; exit 1; }

# Ensure ROS 2 is available
if ! command -v ros2 >/dev/null 2>&1; then
  if [[ -f "/opt/ros/jazzy/setup.bash" ]]; then
    say "Sourcing ROS 2 Jazzy for this shell"
    # shellcheck disable=SC1091
    source "/opt/ros/jazzy/setup.bash"
  fi
fi

command -v ros2 >/dev/null 2>&1 || die "ros2 command not found. Install ROS 2 Jazzy and source /opt/ros/jazzy/setup.bash"

say "Installing system + Python dependencies (project-level)"
"${ROOT_DIR}/scripts/install_deps.sh"

# Frontend dependencies (optional if web folder is a placeholder)
if [[ -f "${ROOT_DIR}/web/package.json" ]]; then
  if command -v npm >/dev/null 2>&1; then
    say "Installing frontend dependencies (npm ci)"
    (cd "${ROOT_DIR}/web" && npm ci)
  else
    die "npm not found. Install Node.js + npm, or use Codespaces/devcontainer."
  fi
else
  say "No web/package.json found. Skipping npm install."
fi

say "Building ROS workspace"
"${ROOT_DIR}/scripts/build_ros.sh"

say "Building frontend and copying assets into ROS package"
"${ROOT_DIR}/scripts/build_frontend.sh"

cat <<'DONE'

Bootstrap complete.

Next steps (in the same terminal):
  1) Source the workspace:
     source ros2/install/setup.bash

  2) Launch the UI:
     ./scripts/run.sh --launch
DONE
