#!/usr/bin/env bash
set -euo pipefail

# Installs ROS 2 Jazzy (Ubuntu 24.04 only) and bootstraps this repo.
# Safe by default: does not modify ~/.bashrc.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() { printf "\n==> %s\n" "$1"; }

die() { printf "\nERROR: %s\n" "$1" >&2; exit 1; }

if [[ "$(id -u)" -eq 0 ]]; then
  die "Do not run as root. Run as a normal user with sudo access."
fi

# Verify Ubuntu 24.04
if ! command -v lsb_release >/dev/null 2>&1; then
  say "Installing lsb-release"
  sudo apt-get update -y
  sudo apt-get install -y lsb-release
fi

DIST="$(lsb_release -is 2>/dev/null || true)"
REL="$(lsb_release -rs 2>/dev/null || true)"
CODENAME="$(lsb_release -cs 2>/dev/null || true)"

if [[ "${DIST}" != "Ubuntu" || "${REL}" != "24.04" ]]; then
  cat <<MSG
This script supports Ubuntu 24.04 only (ROS 2 Jazzy).
Detected: ${DIST} ${REL} (${CODENAME})

Options:
- Use Codespaces/devcontainer (recommended).
- Install ROS 2 manually for your OS, then run: ./bootstrap.sh
MSG
  exit 1
fi

# Install prerequisites
say "Installing system prerequisites"
sudo apt-get update -y
sudo apt-get install -y \
  curl \
  gnupg \
  lsb-release \
  ca-certificates \
  software-properties-common \
  build-essential \
  python3-pip \
  python3-venv \
  git

# Add ROS 2 apt repo (idempotent)
if [[ ! -f /usr/share/keyrings/ros-archive-keyring.gpg ]]; then
  say "Adding ROS 2 apt key"
  sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
    -o /tmp/ros.key
  sudo gpg --dearmor -o /usr/share/keyrings/ros-archive-keyring.gpg /tmp/ros.key
  sudo rm -f /tmp/ros.key
fi

ROS_LIST_FILE="/etc/apt/sources.list.d/ros2.list"
ROS_LINE="deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu ${CODENAME} main"

if [[ ! -f "${ROS_LIST_FILE}" ]] || ! grep -q "packages.ros.org/ros2/ubuntu" "${ROS_LIST_FILE}"; then
  say "Adding ROS 2 apt repository"
  echo "${ROS_LINE}" | sudo tee "${ROS_LIST_FILE}" >/dev/null
fi

say "Installing ROS 2 Jazzy (desktop)"
sudo apt-get update -y
sudo apt-get install -y ros-jazzy-desktop

say "Installing rosdep"
sudo apt-get install -y python3-rosdep

if [[ ! -f /etc/ros/rosdep/sources.list.d/20-default.list ]]; then
  say "Initializing rosdep"
  sudo rosdep init
fi

say "Updating rosdep"
rosdep update

say "Sourcing ROS 2 Jazzy for this shell"
# shellcheck disable=SC1091
source /opt/ros/jazzy/setup.bash

# Install ROS package deps for the workspace (if available)
if [[ -d "${ROOT_DIR}/ros2/src" ]]; then
  say "Resolving ROS dependencies via rosdep"
  rosdep install --from-paths "${ROOT_DIR}/ros2/src" -y --ignore-src || true
fi

say "Bootstrapping project (deps + build)"
exec "${ROOT_DIR}/scripts/bootstrap_project.sh"
