#!/usr/bin/env bash
set -euo pipefail

# Backwards-compatible entrypoint.
# Prefer: ../bootstrap.sh  (or ./bootstrap.sh)

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec "${ROOT_DIR}/scripts/bootstrap_project.sh"
