#!/usr/bin/env bash
set -euo pipefail

# clean.sh
# Removes generated artifacts to keep the repo tidy (especially for zips/shares).

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "[clean] Removing ROS build artifacts..."
rm -rf "${REPO_ROOT}/ros2/build" "${REPO_ROOT}/ros2/install" "${REPO_ROOT}/ros2/log" || true

echo "[clean] Removing web/node_modules and frontend builds..."
rm -rf "${REPO_ROOT}/web/node_modules" "${REPO_ROOT}/web/dist" "${REPO_ROOT}/web/build" || true

echo "[clean] DONE."
