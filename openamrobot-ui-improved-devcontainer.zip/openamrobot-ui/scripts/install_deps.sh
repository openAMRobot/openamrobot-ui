#!/usr/bin/env bash
set -euo pipefail

# install_deps.sh
# Installs minimal dependencies required to build/run THIS repo.
#
# Assumptions:
# - ROS2 is already installed on the system.
# - You have sourced ROS2 before running (or ros2 is in PATH).
#
# This script DOES NOT:
# - install ROS2 itself
# - modify ~/.bashrc
# - create workspaces in ~/
#
# It only installs:
# - system packages commonly required for UI + ROS bridge
# - Python packages for Flask app (local user install by default)
# - Node deps are handled by scripts/build_frontend.sh

if ! command -v ros2 &> /dev/null; then
  echo "ERROR: 'ros2' command not found. Install ROS2 and source it first."
  exit 1
fi

echo "[install_deps] Updating apt..."
sudo apt-get update -y

# Install useful base tools
sudo apt-get install -y       python3-pip       python3-venv       curl       git

# ROS packages (best-effort; some distros may not have all packages)
ROS_DISTRO="$(ros2 --version 2>/dev/null | head -n 1 | awk '{print $NF}' || true)"
if [ -z "${ROS_DISTRO}" ]; then
  # Fallback: environment variable if set
  ROS_DISTRO="${ROS_DISTRO:-}"
fi

if [ -n "${ROS_DISTRO}" ]; then
  echo "[install_deps] Detected ROS distro: ${ROS_DISTRO}"
  sudo apt-get install -y         "ros-${ROS_DISTRO}-rosbridge-server"         || echo "WARNING: rosbridge-server not installed (package may not exist for this distro)."

  sudo apt-get install -y         "ros-${ROS_DISTRO}-web-video-server"         || echo "WARNING: web-video-server not installed (package may not exist for this distro)."
else
  echo "WARNING: Could not detect ROS_DISTRO automatically. Skipping ROS apt packages."
fi

# Python requirements for Flask app
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REQ_FILE="${REPO_ROOT}/requirements.txt"
if [ -f "${REQ_FILE}" ]; then
  echo "[install_deps] Installing Python requirements from requirements.txt"
  python3 -m pip install --user -r "${REQ_FILE}"
else
  echo "WARNING: requirements.txt not found; skipping Python pip deps."
fi

echo "[install_deps] DONE."
