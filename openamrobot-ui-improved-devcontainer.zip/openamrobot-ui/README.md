# OpenAMRobot UI (ROS 2)

ACTIVE REPOSITORY

This is the main OpenAMRobot UI repository. All new UI development happens here.

Legacy repositories (kept for reference only):
- OpenAMRobot_UI_package (legacy UI package repository)
- OpenAMRobot_UI_dev (legacy early UI development sandbox)

---

## Repository layout (high level)

- web/
  Frontend source code (Node.js). Builds to a static bundle.

- ros2/
  ROS 2 workspace (Python package `openamr_ui_package`) containing:
  - Flask app (`flask_app.py`)
  - templates/ (HTML)
  - static/ (built frontend assets)

- scripts/
  Project scripts for installing deps, building, and running.

---

## Quickstart

### Option A (recommended): GitHub Codespaces / devcontainer

1) Open this repository in Codespaces (or VS Code Dev Containers).
   The container already provides ROS 2 Jazzy + Node.js.

2) Bootstrap everything (deps + build):

   ./bootstrap.sh

3) Launch the UI:

   source ros2/install/setup.bash
   ./scripts/run.sh --launch

---

### Option B: Local Ubuntu 24.04 (installs ROS 2 Jazzy for you)

Run the one-command bootstrap that installs ROS 2 Jazzy (if missing) and sets up the repo:

   ./bootstrap.sh --with-ros

Then launch:

   source ros2/install/setup.bash
   ./scripts/run.sh --launch

Notes:
- This installer supports Ubuntu 24.04 only (ROS 2 Jazzy).
- It does not modify your shell rc files (e.g., ~/.bashrc). You can add sourcing yourself if you want.

---

## Common commands

Build everything (fresh workspace):

   ./scripts/run.sh --build-all

Build + run in one go:

   ./scripts/run.sh --build-all --launch

Reset repo-generated artifacts:

   ./scripts/clean.sh

---

## Notes

- `compile_ui.bash` and `launch.bash` are kept as legacy wrappers.
  Prefer scripts in `./scripts/`.

- The frontend build output is copied into:
  - ros2/openamr_ui_package/openamr_ui_package/static/
  - ros2/openamr_ui_package/openamr_ui_package/templates/index.html
