#!/usr/bin/env bash
set -euo pipefail

# compile_ui.bash (legacy wrapper)
# Preferred: ./scripts/build_frontend.sh
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"${REPO_ROOT}/scripts/build_frontend.sh"
