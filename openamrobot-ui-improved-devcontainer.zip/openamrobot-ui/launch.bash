#!/usr/bin/env bash
set -euo pipefail

# launch.bash (legacy wrapper)
# Preferred: ./scripts/run.sh --launch
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"${REPO_ROOT}/scripts/run.sh" --launch
