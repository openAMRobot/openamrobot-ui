# About

Source folder, contains the whole code of the package: the **nodes** (bellow), the **core functions** in
submodules, the **UI** in static and the HTML template in **template**.

