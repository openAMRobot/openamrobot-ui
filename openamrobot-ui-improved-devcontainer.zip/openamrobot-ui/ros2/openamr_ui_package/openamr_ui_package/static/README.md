# About

UI code folder in minified form

# DO NOT TOUCH

Modifications to the web UI should be done in **robotui** and then passed on to this folder (using
**compile_ui.bash** for convenience)
