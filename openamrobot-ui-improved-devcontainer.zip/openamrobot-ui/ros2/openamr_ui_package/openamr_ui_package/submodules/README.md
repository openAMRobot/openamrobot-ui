# About
If some functions need to be used among several nodes (such as config file loading), they are stored here for the sake of code clarity
