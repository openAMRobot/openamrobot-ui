# About
HTML template made for the UI, built automatically using npm

# When to modify
If another JS file is added, then it needs to be called in the file (using the same <script defer ...> tag as the others)
