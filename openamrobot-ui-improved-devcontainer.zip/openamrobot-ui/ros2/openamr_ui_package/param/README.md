# About

Config files that store parameters for the different nodes and functions of the package.

# Modifying

In **config.yaml** (DO NOT MODIFY THE OTHER FILES), simply change the values (On the right-
side of a colon) to the desired parameter
