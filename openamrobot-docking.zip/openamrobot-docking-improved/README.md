# openamrobot-docking

Autodocking package repository for OpenAMRobot.

## Purpose

This repository contains the ROS2 docking package and its supporting documentation. Its current priority is not feature expansion, but refinement of the existing docking pipeline so it becomes clearer, more consistent, and easier to reproduce and maintain.

## Package

- `openamrobot_docking/` - main ROS2 package

## Current focus

- naming consistency
- documentation quality
- package clarity
- release readiness

## Main documentation entry points

- `openamrobot_docking/README.md`
- `openamrobot_docking/docs/README.md`
